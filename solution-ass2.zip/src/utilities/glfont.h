#pragma once

#include <string>
#include "mesh.h"

Mesh generateTextGeometryBuffer(std::string text, float characterHeightOverWidth, float totalTextWidth);